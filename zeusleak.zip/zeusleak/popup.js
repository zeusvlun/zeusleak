
let toggles = ["generics", "specifics", "aws", "checkEnv", "checkGit", "alerts", "notifications", "uniqueByHostname"];

// اجعل notifications = true بدل false
let toggleDefaults = {
    "generics": true,       // أول اختيار مفعّل
    "specifics": true,      // ثاني اختيار مفعّل
    "aws": true,
    "checkEnv": false,
    "checkGit": false,
    "alerts": true,         // Alerts مفعّلة
    "notifications": true,  // Notifications مفعّلة تلقائيًا الآن
    "uniqueByHostname": false
};


for (let toggle of toggles) {
    chrome.storage.sync.get([toggle], function(result) {
        
        if (result[toggle] == undefined) {
            document.getElementById(toggle).checked = toggleDefaults[toggle];
            let setObj = {};
            setObj[toggle] = toggleDefaults[toggle];
            chrome.storage.sync.set(setObj);
        } else if (result[toggle] === true) {
            document.getElementById(toggle).checked = true;
        }
    });

   
    document.getElementById(toggle).addEventListener('click', function() {
        let toggleChecked = document.getElementById(toggle).checked;
        let value = toggleChecked ? true : false;
        let setObj = {};
        setObj[toggle] = value;
        chrome.storage.sync.set(setObj);
    });
}


function htmlEntities(str) {
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}


var acc = document.getElementsByClassName("accordion");
for (let i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.display === "block") {
      panel.style.display = "none";
    } else {
      panel.style.display = "block";
      
      var el = document.getElementById("denyList");
      chrome.storage.sync.get(["originDenyList"], function(result) {
        if (result.originDenyList) {
          el.value = result.originDenyList.join(",");
        } else {
          el.value = "";
        }
        el.focus();
      });

      
      chrome.tabs.query({currentWindow: true, active: true}).then(function(tabs) {
        var origin = (new URL(tabs[0].url)).origin;
        chrome.storage.sync.get(["leakedKeys"], function(result) {
            var keys = result.leakedKeys ? result.leakedKeys[origin] : [];
            if (!keys) keys = [];
            let htmlList = "";
            for (let key of keys) {
                let keyInfo = key["key"] + ": " + key["match"] + " found in " + key["src"];
                if (key["encoded"]) {
                     keyInfo += " decoded from " + key["encoded"].substring(0,9) + "...";
                }
                keyInfo = htmlEntities(keyInfo);
                htmlList += "<li>" + keyInfo + "</li>\n";
            }
            document.getElementById("findingList").innerHTML = htmlList;
        });
      });
    }
  });
}


function downloadCSV() {
    chrome.storage.sync.get(["leakedKeys"], function(result) {
        let csvRows = [];
        if (!result.leakedKeys) {
          result.leakedKeys = {};
        }
        for (let origin in result.leakedKeys) {
            let findings = result.leakedKeys[origin];
            for (let finding of findings) {
                csvRows.push([
                  origin,
                  finding["src"] || "",
                  finding["parentUrl"] || "",
                  finding["key"] || "",
                  finding["match"] || "",
                  finding["encoded"] || ""
                ]);
            }
        }
        let csvContent = csvRows.map(e => e.join(",")).join("\n");
        let hideEl = document.createElement('a');
        hideEl.href = 'data:text/csv;charset=utf-8,%EF%BB%BF' + encodeURI(csvContent);
        hideEl.target = '_blank';
        hideEl.download = 'zeusleak_findings.csv';
        document.body.appendChild(hideEl);
        hideEl.click();
        document.body.removeChild(hideEl);
    });
}


document.getElementById("downloadAllFindings").addEventListener("click", function() {
    downloadCSV();
});


document.getElementById("clearOriginFindings").addEventListener("click", function() {
    chrome.storage.sync.get(["leakedKeys"], function(result) {
        if (!result.leakedKeys) result.leakedKeys = {};
        chrome.tabs.query({currentWindow: true, active: true}).then(function(tabs) {
            let origin = (new URL(tabs[0].url)).origin;
            result.leakedKeys[origin] = [];
            chrome.storage.sync.set({"leakedKeys": result.leakedKeys});
            // تحديث الـ Badge (Manifest V2) - لو Manifest V3 استخدم chrome.action.setBadgeText
            chrome.browserAction.setBadgeText({text: ''});
            document.getElementById("findingList").innerHTML = "";
        });
    });
});


document.getElementById("clearAllFindings").addEventListener("click", function() {
    chrome.storage.sync.get(["leakedKeys"], function(result) {
        if (!result.leakedKeys) result.leakedKeys = {};
        chrome.tabs.query({currentWindow: true, active: true}).then(function(tabs) {
            result.leakedKeys = {};
            chrome.storage.sync.set({"leakedKeys": result.leakedKeys});
            chrome.browserAction.setBadgeText({text: ''});
            document.getElementById("findingList").innerHTML = "";
        });
    });
});


document.getElementById("openTabs").addEventListener("click", function() {
    var rawTabList = document.getElementById("tabList").value;
    var tabList = rawTabList.split(",").map(function(item) {
        return item.trim();
    });
    for (let tab of tabList) {
        console.log(tab);
        chrome.tabs.create({ url: tab });
    }
});


var denyListElement = document.getElementById("denyList");
var changeEvent = function() {
    var rawDenyList = denyListElement.value;
    var denyList = rawDenyList.split(",").map(function(item) {
        return item.trim();
    });
    chrome.storage.sync.set({"originDenyList": denyList});
};

denyListElement.addEventListener('keyup', changeEvent);
denyListElement.addEventListener('paste', changeEvent);
